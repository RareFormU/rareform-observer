// ─────────────────────────────────────────────────────────────
// api/sui.js — Vercel Serverless Function
// Sui Network data via public JSON-RPC
// No API key required
// ─────────────────────────────────────────────────────────────

const THRESHOLD_USD = parseInt(process.env.QUEENS_MOVE_THRESHOLD_USD || '50000');
const SUI_RPC       = 'https://fullnode.mainnet.sui.io:443';

async function suiRpc(method, params = []) {
  const res = await fetch(SUI_RPC, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params })
  });
  const data = await res.json();
  return data.result;
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET');

  try {
    // ── 1. PARALLEL FETCH ─────────────────────────────────────
    const [checkpointRes, suiPrice] = await Promise.all([
      // Latest checkpoint contains recent transactions
      suiRpc('sui_getLatestCheckpointSequenceNumber'),
      fetch('https://api.coingecko.com/api/v3/simple/price?ids=sui&vs_currencies=usd')
        .then(r => r.json()).catch(() => ({ sui: { usd: 3.82 } }))
    ]);

    const price          = suiPrice?.sui?.usd || 3.82;
    const latestSeq      = parseInt(checkpointRes || '0');

    // ── 2. FETCH RECENT CHECKPOINTS FOR TX DATA ───────────────
    const checkpoints = await Promise.all(
      // Get last 3 checkpoints
      [latestSeq, latestSeq - 1, latestSeq - 2]
        .filter(n => n > 0)
        .map(seq => suiRpc('sui_getCheckpoint', [String(seq)]))
    );

    // ── 3. FETCH LARGE SUI TRANSFERS ─────────────────────────
    // Query recent large coin transactions via Sui's queryTransactionBlocks
    const largeTxRes = await suiRpc('suix_queryTransactionBlocks', [
      {
        filter: { InputObject: '0x2::sui::SUI' },
        options: {
          showInput:   true,
          showEffects: true,
          showEvents:  true
        }
      },
      null, // cursor
      10,   // limit
      true  // descending
    ]);

    const txBlocks = largeTxRes?.data || [];

    const moves = txBlocks
      .map(tx => {
        // Extract SUI transfer amounts from transaction inputs
        const inputs = tx.transaction?.data?.transaction?.inputs || [];
        const suiInput = inputs.find(i => i.type === 'pure' && i.valueType === 'u64');
        const rawAmount = suiInput ? parseInt(suiInput.value) : 0;
        const suiAmount = rawAmount / 1e9;
        const usdValue  = suiAmount * price;

        if (usdValue < THRESHOLD_USD) return null;

        let tier = 'mid';
        if (usdValue >= THRESHOLD_USD * 10) tier = 'high';

        // Detect move type from transaction kind
        const txKind = tx.transaction?.data?.transaction?.kind || 'ProgrammableTransaction';
        const action = txKind === 'ProgrammableTransaction' ? 'SUI MOVE CALL' : 'SUI TRANSFER';

        const sender = tx.transaction?.data?.sender || '';

        return {
          chain:     'SUI',
          tier,
          value:     Math.round(usdValue),
          suiAmount: suiAmount.toFixed(2),
          action,
          from:      sender.slice(2, 7).toUpperCase() || '?????',
          to:        '?????', // recipient resolved from effects
          digest:    tx.digest,
          time:      new Date().toISOString()
        };
      })
      .filter(Boolean)
      .slice(0, 8);

    // ── 4. TPS from checkpoint data ───────────────────────────
    const totalTx  = checkpoints.reduce((acc, cp) => acc + parseInt(cp?.networkTotalTransactions || 0), 0);
    const tps      = checkpoints[0]
      ? Math.round(parseInt(checkpoints[0].networkTotalTransactions || 0) / 2)
      : 850;

    // ── 5. VOLUME from DeFiLlama ──────────────────────────────
    const llamaRes  = await fetch('https://api.llama.fi/overview/dexs/sui?excludeTotalDataChart=true&excludeTotalDataChartBreakdown=true').catch(() => null);
    const llamaData = llamaRes?.ok ? await llamaRes.json() : {};
    const volume24h = llamaData.total24h ? (llamaData.total24h / 1e9).toFixed(2) : '0.9';

    return res.status(200).json({
      chain:      'SUI',
      tps,
      volume:     volume24h,
      price,
      checkpoint: latestSeq,
      moves,
      ts:         Date.now()
    });

  } catch (err) {
    console.error('[sui.js]', err);
    return res.status(500).json({ error: err.message });
  }
}
