// ─────────────────────────────────────────────────────────────
// api/xrp.js — Vercel Serverless Function
// XRP Ledger data via public XRPL WebSocket nodes
// No API key required — keyless public endpoint
// ─────────────────────────────────────────────────────────────

const THRESHOLD_USD = parseInt(process.env.QUEENS_MOVE_THRESHOLD_USD || '50000');

// Public XRPL nodes — no key needed
const XRPL_HTTP = 'https://s1.ripple.com:51234/';

async function xrplRequest(method, params = {}) {
  const res = await fetch(XRPL_HTTP, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ method, params: [params] })
  });
  const data = await res.json();
  return data.result;
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET');

  try {
    // ── 1. SERVER INFO (TPS equivalent = txn_per_second) ─────
    const [serverInfo, ledgerData, xrpPrice] = await Promise.all([
      xrplRequest('server_info'),
      xrplRequest('ledger', {
        ledger_index: 'validated',
        transactions: true,
        expand:       true
      }),
      // XRP price from CoinGecko (no key needed for basic endpoint)
      fetch('https://api.coingecko.com/api/v3/simple/price?ids=ripple&vs_currencies=usd')
        .then(r => r.json()).catch(() => ({ ripple: { usd: 2.14 } }))
    ]);

    const tps   = serverInfo?.info?.load_factor || null;
    const price = xrpPrice?.ripple?.usd || 2.14;

    // ── 2. PARSE LARGE TRANSACTIONS FROM LATEST LEDGER ───────
    const txns  = ledgerData?.ledger?.transactions || [];
    const moves = txns
      .filter(tx => tx.TransactionType === 'Payment' && tx.Amount && typeof tx.Amount === 'string')
      .map(tx => {
        const xrpAmount = (parseInt(tx.Amount) / 1e6);
        const usdValue  = xrpAmount * price;

        let tier = 'low';
        if (usdValue >= THRESHOLD_USD * 10) tier = 'high';
        else if (usdValue >= THRESHOLD_USD)  tier = 'mid';

        // Classify action type
        const hasDestTag  = tx.DestinationTag !== undefined;
        const action = hasDestTag ? 'CEX DEPOSIT' : 'XRP TRANSFER';

        return {
          chain:   'XRP',
          tier,
          value:   Math.round(usdValue),
          xrpAmount: xrpAmount.toFixed(0),
          action,
          from:    tx.Account?.slice(0,5).toUpperCase()      || '?????',
          to:      tx.Destination?.slice(0,5).toUpperCase()  || '?????',
          hash:    tx.hash,
          time:    new Date().toISOString() // ledger close time
        };
      })
      .filter(m => m.tier !== 'low')
      .slice(0, 8); // cap at 8 moves per ledger

    // ── 3. 24H VOLUME from DeFiLlama ─────────────────────────
    const llamaRes  = await fetch('https://api.llama.fi/overview/dexs/xrpl?excludeTotalDataChart=true&excludeTotalDataChartBreakdown=true').catch(() => null);
    const llamaData = llamaRes?.ok ? await llamaRes.json() : {};
    const volume24h = llamaData.total24h ? (llamaData.total24h / 1e9).toFixed(2) : '1.8';

    return res.status(200).json({
      chain:       'XRP',
      tps:         Math.floor(tps * 100) || 1500,
      volume:      volume24h,
      price,
      ledgerIndex: ledgerData?.ledger?.ledger_index || null,
      moves,
      ts:          Date.now()
    });

  } catch (err) {
    console.error('[xrp.js]', err);
    return res.status(500).json({ error: err.message });
  }
}
