// ─────────────────────────────────────────────────────────────
// api/solana.js — Vercel Serverless Function
// Relays Helius enhanced transaction data to the HUD
// Your HELIUS_API_KEY stays server-side, never exposed
// ─────────────────────────────────────────────────────────────

const HELIUS_API_KEY = process.env.HELIUS_API_KEY;
const THRESHOLD_USD  = parseInt(process.env.QUEENS_MOVE_THRESHOLD_USD || '50000');

// Helius enhanced transactions endpoint
// Returns the last N transactions with USD values resolved
const HELIUS_URL = `https://api.helius.xyz/v0/transactions/?api-key=${HELIUS_API_KEY}`;

// Known large program addresses to label moves
const PROGRAM_LABELS = {
  'JUP6LkbZbjS1jKKwapdHNy74zcZ3tLUZoi5QNyVTaV4': 'Jupiter DEX Swap',
  'whirLbMiicVdio4qvUfM5KAg6Ct8VwpYzGff3sFjNo':  'Orca Whirlpool',
  '9W959DqEETiGZocYWCQPaJ6sBmUzgfxXfqGeTEdp3aQP': 'Raydium Swap',
  'EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm': 'deBridge',
  'mv3ekLzLbnVPNxjSKvqBpU3ZeZXPQdEC3bp5MDEBG68':  'Marginfi',
};

export default async function handler(req, res) {
  // CORS — allow your HUD to call this
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET');

  if (!HELIUS_API_KEY || HELIUS_API_KEY === 'your_helius_api_key_here') {
    return res.status(500).json({
      error: 'HELIUS_API_KEY not configured',
      hint: 'Add your key to .env.local or Vercel environment variables'
    });
  }

  try {
    // ── 1. NETWORK STATS (TPS, slot, epoch) ──────────────────
    const [statsRes, largeTxRes] = await Promise.all([
      fetch(`https://api.helius.xyz/v0/network/stats?api-key=${HELIUS_API_KEY}`),
      // Enhanced transactions — parsed, with token transfers & USD values
      fetch(`https://api.helius.xyz/v0/addresses/search?api-key=${HELIUS_API_KEY}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: { nativeTransfers: { minAmount: 10000 } }, // 10k+ SOL moves
          options: { limit: 10 }
        })
      })
    ]);

    const stats   = statsRes.ok   ? await statsRes.json()   : {};
    const largeTx = largeTxRes.ok ? await largeTxRes.json() : { result: [] };

    // ── 2. PARSE LARGE TRANSACTIONS ───────────────────────────
    const moves = (largeTx.result || [])
      .filter(tx => tx.nativeTransfers?.length > 0)
      .map(tx => {
        const transfer = tx.nativeTransfers[0];
        const solAmount = (transfer.amount / 1e9).toFixed(2);
        const usdValue  = solAmount * (stats.solPrice || 148);

        // Classify tier by USD value
        let tier = 'low';
        if (usdValue >= THRESHOLD_USD * 10) tier = 'high';
        else if (usdValue >= THRESHOLD_USD) tier  = 'mid';

        // Label the action
        const programLabel = tx.instructions
          ?.map(ix => PROGRAM_LABELS[ix.programId])
          .find(Boolean) || 'SOL TRANSFER';

        return {
          chain:   'SOL',
          tier,
          value:   Math.round(usdValue),
          solAmount,
          action:  programLabel,
          from:    transfer.fromUserAccount?.slice(0,5).toUpperCase() || '?????',
          to:      transfer.toUserAccount?.slice(0,5).toUpperCase()   || '?????',
          sig:     tx.signature,
          time:    new Date(tx.timestamp * 1000).toISOString()
        };
      })
      .filter(m => m.tier !== 'low'); // Only surface mid/high to the HUD

    // ── 3. VOLUME ESTIMATE (rolling 24h from Helius) ──────────
    // Note: Helius free tier — use their /v0/network/stats endpoint
    // for real-time TPS; 24h volume comes from DeFiLlama (no key needed)
    const llamaRes  = await fetch('https://api.llama.fi/overview/dexs/solana?excludeTotalDataChart=true&excludeTotalDataChartBreakdown=true');
    const llamaData = llamaRes.ok ? await llamaRes.json() : {};
    const volume24h = llamaData.total24h ? (llamaData.total24h / 1e9).toFixed(2) : null;

    // ── 4. RETURN UNIFIED PAYLOAD ─────────────────────────────
    return res.status(200).json({
      chain:   'SOL',
      tps:     stats.currentTps     || null,
      volume:  volume24h             || null, // billions USD
      price:   stats.solPrice        || null,
      slot:    stats.absoluteSlot    || null,
      moves,
      ts:      Date.now()
    });

  } catch (err) {
    console.error('[solana.js]', err);
    return res.status(500).json({ error: err.message });
  }
}
