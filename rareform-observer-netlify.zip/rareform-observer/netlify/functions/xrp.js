// netlify/functions/xrp.js
// Netlify Serverless Function — XRPL public node relay
// No API key required

const THRESHOLD_USD = parseInt(process.env.QUEENS_MOVE_THRESHOLD_USD || '50000');
const XRPL_HTTP     = 'https://s1.ripple.com:51234/';

async function xrplRequest(method, params = {}) {
  const res = await fetch(XRPL_HTTP, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify({ method, params: [params] })
  });
  const data = await res.json();
  return data.result;
}

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET',
    'Content-Type': 'application/json'
  };

  try {
    const [serverInfo, ledgerData, priceRes] = await Promise.all([
      xrplRequest('server_info'),
      xrplRequest('ledger', {
        ledger_index: 'validated',
        transactions: true,
        expand:       true
      }),
      fetch('https://api.coingecko.com/api/v3/simple/price?ids=ripple&vs_currencies=usd')
        .then(r => r.json()).catch(() => ({ ripple: { usd: 2.14 } }))
    ]);

    const price = priceRes?.ripple?.usd || 2.14;
    const txns  = ledgerData?.ledger?.transactions || [];

    const moves = txns
      .filter(tx =>
        tx.TransactionType === 'Payment' &&
        tx.Amount &&
        typeof tx.Amount === 'string'
      )
      .map(tx => {
        const xrpAmount = parseInt(tx.Amount) / 1e6;
        const usdValue  = xrpAmount * price;

        let tier = 'low';
        if (usdValue >= THRESHOLD_USD * 10) tier = 'high';
        else if (usdValue >= THRESHOLD_USD)  tier = 'mid';

        const action = tx.DestinationTag !== undefined
          ? 'CEX DEPOSIT'
          : 'XRP TRANSFER';

        return {
          chain:     'XRP',
          tier,
          value:     Math.round(usdValue),
          xrpAmount: xrpAmount.toFixed(0),
          action,
          from:      tx.Account?.slice(0,5).toUpperCase()     || '?????',
          to:        tx.Destination?.slice(0,5).toUpperCase() || '?????',
          hash:      tx.hash,
          time:      new Date().toISOString()
        };
      })
      .filter(m => m.tier !== 'low')
      .slice(0, 8);

    const llamaRes  = await fetch('https://api.llama.fi/overview/dexs/xrpl?excludeTotalDataChart=true&excludeTotalDataChartBreakdown=true').catch(() => null);
    const llamaData = llamaRes?.ok ? await llamaRes.json() : {};
    const volume24h = llamaData.total24h
      ? (llamaData.total24h / 1e9).toFixed(2)
      : '1.8';

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        chain:       'XRP',
        tps:         Math.floor((serverInfo?.info?.load_factor || 15) * 100),
        volume:      volume24h,
        price,
        ledgerIndex: ledgerData?.ledger?.ledger_index || null,
        moves,
        ts:          Date.now()
      })
    };

  } catch (err) {
    console.error('[xrp]', err);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: err.message })
    };
  }
};
