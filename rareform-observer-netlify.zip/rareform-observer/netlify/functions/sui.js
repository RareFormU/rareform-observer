// netlify/functions/sui.js
// Netlify Serverless Function — Sui public RPC relay
// No API key required

const THRESHOLD_USD = parseInt(process.env.QUEENS_MOVE_THRESHOLD_USD || '50000');
const SUI_RPC       = 'https://fullnode.mainnet.sui.io:443';

async function suiRpc(method, params = []) {
  const res = await fetch(SUI_RPC, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify({ jsonrpc: '2.0', id: 1, method, params })
  });
  const data = await res.json();
  return data.result;
}

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET',
    'Content-Type': 'application/json'
  };

  try {
    const [checkpointSeq, priceRes] = await Promise.all([
      suiRpc('sui_getLatestCheckpointSequenceNumber'),
      fetch('https://api.coingecko.com/api/v3/simple/price?ids=sui&vs_currencies=usd')
        .then(r => r.json()).catch(() => ({ sui: { usd: 3.82 } }))
    ]);

    const price     = priceRes?.sui?.usd || 3.82;
    const latestSeq = parseInt(checkpointSeq || '0');

    // Recent large transactions
    const largeTxRes = await suiRpc('suix_queryTransactionBlocks', [
      { filter: { InputObject: '0x2::sui::SUI' } },
      null,
      10,
      true
    ]);

    const txBlocks = largeTxRes?.data || [];

    const moves = txBlocks
      .map(tx => {
        const inputs    = tx.transaction?.data?.transaction?.inputs || [];
        const suiInput  = inputs.find(i => i.type === 'pure' && i.valueType === 'u64');
        const rawAmount = suiInput ? parseInt(suiInput.value) : 0;
        const suiAmount = rawAmount / 1e9;
        const usdValue  = suiAmount * price;

        if (usdValue < THRESHOLD_USD) return null;

        let tier = 'mid';
        if (usdValue >= THRESHOLD_USD * 10) tier = 'high';

        const sender = tx.transaction?.data?.sender || '';

        return {
          chain:     'SUI',
          tier,
          value:     Math.round(usdValue),
          suiAmount: suiAmount.toFixed(2),
          action:    'SUI MOVE CALL',
          from:      sender.slice(2,7).toUpperCase() || '?????',
          to:        '?????',
          digest:    tx.digest,
          time:      new Date().toISOString()
        };
      })
      .filter(Boolean)
      .slice(0, 8);

    const llamaRes  = await fetch('https://api.llama.fi/overview/dexs/sui?excludeTotalDataChart=true&excludeTotalDataChartBreakdown=true').catch(() => null);
    const llamaData = llamaRes?.ok ? await llamaRes.json() : {};
    const volume24h = llamaData.total24h
      ? (llamaData.total24h / 1e9).toFixed(2)
      : '0.9';

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        chain:      'SUI',
        tps:        850,
        volume:     volume24h,
        price,
        checkpoint: latestSeq,
        moves,
        ts:         Date.now()
      })
    };

  } catch (err) {
    console.error('[sui]', err);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: err.message })
    };
  }
};
