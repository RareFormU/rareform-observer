// netlify/functions/solana.js
// Netlify Serverless Function — Helius relay
// Your HELIUS_API_KEY stays server-side

const HELIUS_API_KEY = process.env.HELIUS_API_KEY;
const THRESHOLD_USD  = parseInt(process.env.QUEENS_MOVE_THRESHOLD_USD || '50000');

const PROGRAM_LABELS = {
  'JUP6LkbZbjS1jKKwapdHNy74zcZ3tLUZoi5QNyVTaV4': 'Jupiter DEX Swap',
  'whirLbMiicVdio4qvUfM5KAg6Ct8VwpYzGff3sFjNo':  'Orca Whirlpool',
  '9W959DqEETiGZocYWCQPaJ6sBmUzgfxXfqGeTEdp3aQP': 'Raydium Swap',
  'EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm': 'deBridge',
  'mv3ekLzLbnVPNxjSKvqBpU3ZeZXPQdEC3bp5MDEBG68':  'Marginfi',
};

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET',
    'Content-Type': 'application/json'
  };

  if (!HELIUS_API_KEY || HELIUS_API_KEY === 'your_helius_api_key_here') {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: 'HELIUS_API_KEY not configured',
        hint: 'Add your key to Netlify Environment Variables'
      })
    };
  }

  try {
    // ── Network stats + large tx in parallel ─────────────────
    const [statsRes, llamaRes] = await Promise.all([
      fetch(`https://api.helius.xyz/v0/network/stats?api-key=${HELIUS_API_KEY}`),
      fetch('https://api.llama.fi/overview/dexs/solana?excludeTotalDataChart=true&excludeTotalDataChartBreakdown=true')
    ]);

    const stats     = statsRes.ok  ? await statsRes.json()  : {};
    const llamaData = llamaRes.ok  ? await llamaRes.json()  : {};
    const volume24h = llamaData.total24h
      ? (llamaData.total24h / 1e9).toFixed(2)
      : null;

    // ── Fetch recent large transfers via Helius enhanced API ─
    const txRes = await fetch(
      `https://api.helius.xyz/v0/transactions/?api-key=${HELIUS_API_KEY}&type=TRANSFER&source=SYSTEM_PROGRAM`,
      { method: 'GET' }
    );
    const txData = txRes.ok ? await txRes.json() : [];

    const solPrice = stats.solPrice || 148;

    const moves = (Array.isArray(txData) ? txData : [])
      .filter(tx => tx.nativeTransfers?.length > 0)
      .map(tx => {
        const transfer  = tx.nativeTransfers[0];
        const solAmount = (transfer.amount / 1e9).toFixed(2);
        const usdValue  = solAmount * solPrice;

        let tier = 'low';
        if (usdValue >= THRESHOLD_USD * 10) tier = 'high';
        else if (usdValue >= THRESHOLD_USD)  tier = 'mid';

        const programLabel = tx.instructions
          ?.map(ix => PROGRAM_LABELS[ix.programId])
          .find(Boolean) || 'SOL TRANSFER';

        return {
          chain:     'SOL',
          tier,
          value:     Math.round(usdValue),
          solAmount,
          action:    programLabel,
          from:      transfer.fromUserAccount?.slice(0,5).toUpperCase() || '?????',
          to:        transfer.toUserAccount?.slice(0,5).toUpperCase()   || '?????',
          sig:       tx.signature,
          time:      new Date(tx.timestamp * 1000).toISOString()
        };
      })
      .filter(m => m.tier !== 'low')
      .slice(0, 8);

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        chain:  'SOL',
        tps:    stats.currentTps  || null,
        volume: volume24h,
        price:  solPrice,
        slot:   stats.absoluteSlot || null,
        moves,
        ts:     Date.now()
      })
    };

  } catch (err) {
    console.error('[solana]', err);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: err.message })
    };
  }
};
