# RAREFORM OBSERVER — Setup Guide

> Observer Protocol v0.1 // Queen's Move Detection // SOL / XRP / SUI

---

## What This Is

A live on-chain intelligence HUD that watches Solana, XRP Ledger, and Sui
for large transactions ("Queen's Moves") and surfaces them in real time.

The HUD runs in the browser. Three serverless functions on Vercel handle
the chain data — keeping your API key server-side and never exposed.

---

## Prerequisites

You need three things before starting:

1. A GitHub account (free) — github.com
2. A Vercel account (free) — vercel.com → "Sign up with GitHub"
3. A Helius API key (free) — helius.dev → "Get Started"

XRP and Sui need no keys. Solana needs Helius.

---

## Step 1 — Get Your Helius Key

1. Go to https://helius.dev
2. Click "Get Started" → sign up with email or GitHub
3. From your dashboard → "Create New App"
4. Name it "rareform-observer" → any network → Create
5. Copy the API key — looks like: `a1b2c3d4-e5f6-...`
6. Keep this tab open — you'll need it in Step 4

Free tier gives you 100,000 credits/month.
The Observer polls every 8 seconds = ~10,800 calls/day = well within free limits.

---

## Step 2 — Push This Project to GitHub

If you don't have Git installed:
  https://git-scm.com/downloads → install → restart terminal

In your terminal, navigate to this folder then run:

```bash
git init
git add .
git commit -m "init: rareform observer protocol"
```

Then on GitHub.com:
1. Click the "+" icon → "New repository"
2. Name it: `rareform-observer`
3. Keep it Private (your API key goes in Vercel, not here, but still)
4. Click "Create repository"
5. Follow the "push an existing repository" commands GitHub shows you

---

## Step 3 — Deploy to Vercel

1. Go to https://vercel.com → Log in with GitHub
2. Click "Add New Project"
3. Find and import `rareform-observer`
4. Vercel auto-detects the project — no framework to select
5. Click "Deploy" — this first deploy will fail because the key isn't set yet
6. That's fine — go to Step 4

---

## Step 4 — Add Your Environment Variables

In Vercel dashboard → your project → "Settings" → "Environment Variables"

Add these one by one:

| Name                        | Value                          |
|-----------------------------|--------------------------------|
| HELIUS_API_KEY              | your key from Step 1           |
| QUEENS_MOVE_THRESHOLD_USD   | 50000                          |

Click "Save" after each one.

Then: "Deployments" → click the three dots on your latest deploy → "Redeploy"

Your live URL will be: https://rareform-observer.vercel.app (or similar)

---

## Step 5 — Connect the HUD to Live Data

Open `public/index.html` and find this section near the bottom of the script:

```javascript
// ── MAIN SIMULATION LOOP ──
```

Replace everything from that comment to the end of the script with:

```javascript
// ── LIVE DATA ──
import { startLiveData, setOnMove, setOnChain } from '/lib/dataService.js';

setOnMove(addMove);

setOnChain('sol', (data) => {
  if (data.volume) updateChainDisplay('sol', data);
});
setOnChain('xrp', (data) => {
  if (data.volume) updateChainDisplay('xrp', data);
});
setOnChain('sui', (data) => {
  if (data.volume) updateChainDisplay('sui', data);
});

startLiveData();
```

The `addMove()` and `updateChainDisplay()` functions already exist in index.html —
the data service just calls them with real data instead of mock data.

---

## Step 6 — Local Development

To run locally with live data:

```bash
npm install
cp .env.example .env.local
# Edit .env.local and add your real HELIUS_API_KEY
npm run dev
```

Open http://localhost:3000 — identical to production.

---

## Threshold Tuning

`QUEENS_MOVE_THRESHOLD_USD` controls what counts as a "Queen's Move."

| Value     | Effect                                        |
|-----------|-----------------------------------------------|
| 10000     | Lots of alerts — busy, noisy                  |
| 50000     | Balanced — catches real whale activity        |
| 500000    | Only the biggest moves — very quiet           |

Adjust in Vercel env vars → redeploy → no code changes needed.

---

## Project Structure

```
rareform-observer/
├── public/
│   └── index.html          ← The HUD (browser)
├── api/
│   ├── solana.js           ← Helius relay (server, key stays here)
│   ├── xrp.js              ← XRPL public node relay (no key)
│   └── sui.js              ← Sui public RPC relay (no key)
├── lib/
│   └── dataService.js      ← Polling logic, dedup, state
├── .env.example            ← Copy to .env.local for local dev
├── .gitignore              ← Keeps .env.local out of GitHub
├── package.json
├── vercel.json
└── README.md               ← You are here
```

---

## Next Steps (Step 3 of the RareForm build)

Once live data is running:

- [ ] Observer agent personality + lore system
- [ ] PS1 jitter + Three.js world layer behind the HUD
- [ ] Dynamic Observer spawning based on Queen's Move frequency
- [ ] Discord bot that mirrors the move feed
- [ ] Mobile-responsive layout for the HUD

---

## Troubleshooting

**HUD shows mock data still**
→ Did you complete Step 5 and connect the data service?

**API returns "HELIUS_API_KEY not configured"**
→ Check Vercel env vars → redeploy after adding the key

**XRP/Sui showing no moves**
→ Threshold may be too high — try setting QUEENS_MOVE_THRESHOLD_USD to 10000

**CORS errors in browser console**
→ Make sure you're accessing via the Vercel URL, not opening index.html directly as a file

---

*RareForm United // Observer Protocol // Self-Custody Intelligence*
